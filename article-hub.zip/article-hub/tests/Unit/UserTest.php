<?php

namespace App\Tests\Support\Unit;

use App\Entity\User;
use App\Tests\Support\UnitTester;
use Codeception\Test\Unit;

class UserTest extends Unit
{
    protected UnitTester $tester;
    protected User $user;

    protected function setUp(): void
    {
        parent::setUp();
        $this->user = new User();
    }

    public function testGetAndSetEmail()
    {
        $email = "test@example.com";
        $this->user->setEmail($email);
        $this->assertSame($email, $this->user->getEmail());
    }

    public function testGetAndSetPassword()
    {
        $password = "123321";
        $this->user->setPassword($password);
        $this->assertSame($password, $this->user->getPassword());
    }

    public function testGetAndSetIsVerified()
    {
        $this->user->setIsVerified(true);
        $this->assertTrue($this->user->isVerified());
    }

    public function testAddAndRemoveFollower()
    {
        $follower = new User();

        $this->user->addFollower($follower);
        $this->assertTrue($this->user->getFollowers()->contains($follower));

        $this->user->removeFollower($follower);
        $this->assertFalse($this->user->getFollowers()->contains($follower));
    }

    public function testFollowAndUnfollow()
    {
        $followed = new User();

        $this->user->follow($followed);
        $this->assertTrue($this->user->getFollows()->contains($followed));

        $this->user->unfollow($followed);
        $this->assertFalse($this->user->getFollows()->contains($followed));
    }

    public function testSetRoles()
    {
        // Test setting single role
        $singleRole = ['ROLE_USER'];
        $this->user->setRoles($singleRole);
        $this->assertSame($singleRole, $this->user->getRoles());

        // Test setting multiple roles
        $multipleRoles = ['ROLE_USER', 'ROLE_ADMIN', 'ROLE_WRITER'];
        $this->user->setRoles($multipleRoles);
        $this->assertSame($multipleRoles, $this->user->getRoles());

        // Test setting empty array of roles
        $emptyRoles = [];
        $this->user->setRoles($emptyRoles);
        // User should always have at least ROLE_USER
        $this->assertSame(['ROLE_USER'], $this->user->getRoles());
    }
}
