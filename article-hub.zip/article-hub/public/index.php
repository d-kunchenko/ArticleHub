<?php

use App\Kernel;

$fileC3 = dirname(__DIR__) . '/c3.php';
$fileAutoload = dirname(__DIR__) . '/vendor/autoload_runtime.php';

// Перевірка існування файлу c3.php
if (!file_exists($fileC3)) {
    die("Помилка: Файл c3.php не знайдено у шляху " . $fileC3);
}

require $fileC3;

// Перевірка існування файлу autoload_runtime.php
if (!file_exists($fileAutoload)) {
    die("Помилка: Файл autoload_runtime.php не знайдено у шляху " . $fileAutoload);
}

require_once $fileAutoload;

return function (array $context) {
    return new Kernel($context['APP_ENV'], (bool)$context['APP_DEBUG']);
};
